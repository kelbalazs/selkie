<!DOCTYPE html>
<html>
<head>
    <title>Contact Form Submission</title>
</head>
<body>
    <h2>Contact Form Submission</h2>
    <p><strong>Name:</strong> <?php echo e($data['name']); ?></p>
    <p><strong>Email:</strong> <?php echo e($data['email']); ?></p>
    <p><strong>Message:</strong></p>
    <p><?php echo e($data['message']); ?></p>
</body>
</html>
<?php /**PATH /home/balazs/Desktop/selkie/resources/views/emails/contact.blade.php ENDPATH**/ ?>