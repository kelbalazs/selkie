<?php $__env->startSection('content'); ?>
    <h1>Your Cart</h1>

    <?php if(count($cart) > 0): ?>
        <table class="table">
            <thead>
                <tr>
                    <th>Chocolate</th>
                    <th>Price</th>
                    <th>Quantity</th>
                    <th>Total</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $cart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($item['name']); ?></td>
                        <td>£<?php echo e(number_format($item['price'], 2)); ?></td>
                        <td><?php echo e($item['quantity']); ?></td>
                        <td>£<?php echo e(number_format($item['price'] * $item['quantity'], 2)); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

        <h3>Total: £<?php echo e(number_format($totalPrice, 2)); ?></h3>

        <a href="<?php echo e(route('checkout.show')); ?>" class="btn btn-primary">Proceed to Checkout</a>
        <?php else: ?>
        <p>Your cart is empty.</p>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/balazs/Desktop/selkie/resources/views/cart/view.blade.php ENDPATH**/ ?>