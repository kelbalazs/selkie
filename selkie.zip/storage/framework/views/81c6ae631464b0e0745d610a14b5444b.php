<?php $__env->startSection('content'); ?>
    <h1>Thank You for Your Order!</h1>

    <h3>Order Summary</h3>
    <p>Total Price: £<?php echo e(number_format($totalPrice, 2)); ?></p>

    <h4>Items in Your Cart:</h4>
    <ul>
        <?php $__currentLoopData = $cart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($item['name']); ?> (<?php echo e($item['quantity']); ?> x £<?php echo e(number_format($item['price'], 2)); ?>)</li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>

    <p>Your order is now being processed.</p>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/balazs/Desktop/selkie/resources/views/checkout/confirmation.blade.php ENDPATH**/ ?>