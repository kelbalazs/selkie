<!-- resources/views/checkout/checkout.blade.php -->


<?php $__env->startSection('content'); ?>
    <h2>Checkout</h2>

    <p>Review your order and proceed to payment.</p>

    <!-- Cart Summary -->
    <table class="table">
        <thead>
            <tr>
                <th>Name</th>
                <th>Price</th>
                <th>Quantity</th>
                <th>Total</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $cart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($item['name']); ?></td>
                    <td>£<?php echo e(number_format($item['price'], 2)); ?></td>
                    <td><?php echo e($item['quantity']); ?></td>
                    <td>£<?php echo e(number_format($item['price'] * $item['quantity'], 2)); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <h3>Total: £<?php echo e(number_format($totalPrice, 2)); ?></h3>

    <form action="<?php echo e(route('checkout.process')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <button type="submit" class="btn btn-primary">Proceed with Checkout</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/balazs/Desktop/selkie/resources/views/checkout/checkout.blade.php ENDPATH**/ ?>